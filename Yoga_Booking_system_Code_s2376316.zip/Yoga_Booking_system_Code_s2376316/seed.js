import { CourseModel } from "./models/courseModel.js";
import { SessionModel } from "./models/sessionModel.js";
import { UserModel } from "./models/userModel.js";

async function seed() {
  try {
    // --- USERS ---
    const user = await UserModel.create({
      _id: "user1",
      name: "Fiona",
      email: "fiona@example.com",
      password: "password123", // plaintext for simplicity
    });

    // --- COURSES ---
    const course1 = await CourseModel.create({
      _id: "course1",
      title: "Winter Mindfulness Workshop",
      level: "beginner",
      type: "WEEKEND_WORKSHOP",
      allowDropIn: false,
      price: 120, // course price
      startDate: "2026-01-10",
      endDate: "2026-01-11",
      instructorId: "QlUH1BeUc64AhMK5",
      description: "Two days of breath, posture alignment, and meditation.",
    });

    const course2 = await CourseModel.create({
      _id: "course2",
      title: "12-Week Vinyasa Flow",
      level: "intermediate",
      type: "WEEKLY_BLOCK",
      allowDropIn: true,
      price: 250, // course price
      startDate: "2026-02-02",
      endDate: "2026-04-20",
      instructorId: "dZ1GDVNqDeFkepAg",
      description: "Progressive sequences building strength and flexibility.",
    });

    // --- SESSIONS ---
    const sessionsCourse1 = [
      { _id: "s1", courseId: course1._id, startDateTime: "2026-01-10T10:00", endDateTime: "2026-01-10T12:00", capacity: 20, bookedCount: 0, price: 0 },
      { _id: "s2", courseId: course1._id, startDateTime: "2026-01-10T13:00", endDateTime: "2026-01-10T15:00", capacity: 20, bookedCount: 0, price: 0 },
      { _id: "s3", courseId: course1._id, startDateTime: "2026-01-11T10:00", endDateTime: "2026-01-11T12:00", capacity: 20, bookedCount: 0, price: 0 },
      { _id: "s4", courseId: course1._id, startDateTime: "2026-01-11T13:00", endDateTime: "2026-01-11T15:00", capacity: 20, bookedCount: 0, price: 0 },
      { _id: "s5", courseId: course1._id, startDateTime: "2026-01-11T16:00", endDateTime: "2026-01-11T18:00", capacity: 20, bookedCount: 0, price: 0 },
    ];

    const sessionsCourse2 = [];
    let startDate = new Date("2026-02-02T18:30");
    for (let i = 0; i < 12; i++) {
      const start = new Date(startDate.getTime() + i * 7 * 24 * 60 * 60 * 1000); // weekly
      const end = new Date(start.getTime() + 75 * 60 * 1000); // 1h15min
      sessionsCourse2.push({
        _id: `s${i + 6}`,
        courseId: course2._id,
        startDateTime: start.toISOString(),
        endDateTime: end.toISOString(),
        capacity: 18,
        bookedCount: 0,
        price: 25, // per-session price
      });
    }

    await Promise.all([...sessionsCourse1, ...sessionsCourse2].map(s => SessionModel.create(s)));

    console.log("Seed data inserted successfully!");
  } catch (err) {
    console.error("Error seeding data:", err);
  }
}

seed();