import { usersDb } from "./models/_db.js";

async function listUsers() {
  try {
    const users = await usersDb.find({});
    console.log("Users in DB:");
    users.forEach(u => {
      console.log(`- Name: ${u.name}, Email: ${u.email}, PasswordHash: ${u.passwordHash}`);
    });
  } catch (err) {
    console.error("Error reading users:", err);
  } finally {
    process.exit(0);
  }
}

listUsers();