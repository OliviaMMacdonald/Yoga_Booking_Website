// listCourses.js
import { initDb } from "./models/_db.js";
import { CourseModel } from "./models/courseModel.js";

async function listCourses() {
  await initDb(); // make sure DB is initialized

  const courses = await CourseModel.list();
  if (!courses.length) {
    console.log("No courses found.");
    return;
  }

  console.log("Courses in DB:");
  for (const c of courses) {
    console.log(`- ${c.title} [${c.level}] ID: ${c._id}`);
  }
}

listCourses().catch((err) => {
  console.error("Error listing courses:", err);
});