// coursesListController.js
import { CourseModel } from "../models/courseModel.js";
import { SessionModel } from "../models/sessionModel.js";

const fmtDateOnly = (iso) => (iso ? new Date(iso).toLocaleDateString("en-GB") : "");

export const coursesListPage = async (req, res, next) => {
  try {
    const { q, level, dropIn } = req.query;

    let courses = await CourseModel.list();

    // SEARCH
    if (q) {
      const needle = q.toLowerCase();
      courses = courses.filter(
        (c) =>
          c.title.toLowerCase().includes(needle) ||
          c.description.toLowerCase().includes(needle)
      );
    }

    // FILTER BY LEVEL
    if (level) {
      courses = courses.filter((c) => c.level === level);
    }

    // FILTER BY DROP-IN
    if (dropIn === "true") {
      courses = courses.filter((c) => c.allowDropIn);
    }

    // FORMAT courses with next session info
    const cards = await Promise.all(
      courses.map(async (c) => {
        const sessions = await SessionModel.listByCourse(c._id);
        return {
          id: c._id,
          title: c.title,
          level: c.level,
          type: c.type,
          allowDropIn: c.allowDropIn,
          price: c.price ?? "TBA",   // <-- numeric only
          startDate: fmtDateOnly(c.startDate),
          endDate: fmtDateOnly(c.endDate),
          nextSession: sessions[0]
            ? new Date(sessions[0].startDateTime).toLocaleString("en-GB")
            : "TBA",
          sessionsCount: sessions.length,
          description: c.description,
        };
      })
    );

    // Pre-compute filter flags for Mustache
    const filters = {
      q: q || "",
      isBeginner: level === "beginner",
      isIntermediate: level === "intermediate",
      isAdvanced: level === "advanced",
      dropIn: dropIn === "true",
    };

    res.render("courses", { courses: cards, filters, userLoggedIn: !!req.session.user, userName: req.session.user?.name || null });
  } catch (err) {
    console.error(err);
    next(err);
  }
};