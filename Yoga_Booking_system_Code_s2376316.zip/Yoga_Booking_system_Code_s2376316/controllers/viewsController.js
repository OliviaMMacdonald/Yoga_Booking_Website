// viewsController.js
import { CourseModel } from "../models/courseModel.js";
import { SessionModel } from "../models/sessionModel.js";
import { BookingModel } from "../models/bookingModel.js";
import { bookCourseForUser, bookSessionForUser } from "../services/bookingService.js";

// Format date and date+time
const fmtDate = (iso) =>
  new Date(iso).toLocaleString("en-GB", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

const fmtDateOnly = (iso) =>
  (iso ? new Date(iso).toLocaleDateString("en-GB") : "");

// ----------------------------
// HOMEPAGE
// ----------------------------
export const homePage = async (req, res, next) => {
  try {
    const courses = await CourseModel.list();
    const featuredCourses = [];

    for (const c of courses.slice(0, 3)) {
      const sessions = await SessionModel.listByCourse(c._id);
      if (!sessions || sessions.length === 0) continue;

      featuredCourses.push({
        id: c._id,
        title: c.title,
        level: c.level,
        type: c.type,
        allowDropIn: c.allowDropIn,
        price: c.price ?? "TBA",
        startDate: c.startDate ? fmtDateOnly(c.startDate) : "",
        endDate: c.endDate ? fmtDateOnly(c.endDate) : "",
        nextSession: sessions[0] ? fmtDate(sessions[0].startDateTime) : "TBA",
        description: c.description,
        location: c.location ?? "TBA",
      });
    }

    res.render("home", {
      title: "Welcome to Yoga Studio",
      welcomeMessage: "Find balance, flexibility, and calm at our Yoga Studio. Explore our courses and workshops designed for every level.",
      featuredCourses,
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  } catch (err) {
    next(err);
  }
};

// ----------------------------
// COURSES LIST PAGE
// ----------------------------
export const coursesListPage = async (req, res, next) => {
  try {
    const { q, level, dropIn } = req.query;
    let courses = await CourseModel.list();

    if (q) {
      const needle = q.toLowerCase();
      courses = courses.filter(
        (c) =>
          c.title.toLowerCase().includes(needle) ||
          c.description.toLowerCase().includes(needle)
      );
    }

    if (level) courses = courses.filter((c) => c.level === level);
    if (dropIn === "true") courses = courses.filter((c) => c.allowDropIn);

    const cards = [];
    for (const c of courses) {
      const sessions = await SessionModel.listByCourse(c._id);
      if (!sessions || sessions.length === 0) continue;

      cards.push({
        id: c._id,
        title: c.title,
        level: c.level,
        type: c.type,
        allowDropIn: c.allowDropIn,
        price: c.price ?? "TBA",
        startDate: fmtDateOnly(c.startDate),
        endDate: fmtDateOnly(c.endDate),
        nextSession: sessions[0] ? fmtDate(sessions[0].startDateTime) : "TBA",
        sessionsCount: sessions.length,
        description: c.description,
      });
    }

    const filters = {
      q: q || "",
      level: level || "",
      dropIn: dropIn === "true",
      isBeginner: level === "beginner",
      isIntermediate: level === "intermediate",
      isAdvanced: level === "advanced",
    };

    res.render("courses", {
      courses: cards,
      filters,
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  } catch (err) {
    console.error(err);
    next(err);
  }
};

// ----------------------------
// COURSE DETAIL PAGE
// ----------------------------
export const courseDetailPage = async (req, res, next) => {
  try {
    const course = await CourseModel.findById(req.params.id);
    if (!course)
      return res.status(404).render("error", {
        title: "Not found",
        message: "Course not found",
        userLoggedIn: !!req.session.user,
        userName: req.session.user?.name || null,
      });

    const sessions = await SessionModel.listByCourse(course._id);
    const rows = sessions.map((s) => ({
      id: s._id,
      start: fmtDate(s.startDateTime),
      end: fmtDate(s.endDateTime),
      capacity: s.capacity,
      booked: s.bookedCount ?? 0,
      remaining: Math.max(0, (s.capacity ?? 0) - (s.bookedCount ?? 0)),
      canBook: Math.max(0, (s.capacity ?? 0) - (s.bookedCount ?? 0)) > 0,
      courseAllowDropIn: course.allowDropIn === true,
      price: s.price ?? "TBA",
    }));

    const nextSession = sessions.length > 0 ? fmtDate(sessions[0].startDateTime) : "TBA";

    res.render("course", {
      title: course.title,
      course: {
        id: course._id,
        title: course.title,
        level: course.level,
        type: course.type,
        allowDropIn: course.allowDropIn === true,
        price: course.price ?? "TBA",
        startDate: course.startDate ? fmtDateOnly(course.startDate) : "",
        endDate: course.endDate ? fmtDateOnly(course.endDate) : "",
        description: course.description,
        nextSession,
        totalSessions: sessions.length,
      },
      sessions: rows,
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  } catch (err) {
    next(err);
  }
};

// ----------------------------
// BOOKING FUNCTIONS
// ----------------------------
export const postBookCourse = async (req, res, next) => {
  try {
    const booking = await bookCourseForUser(req.session.user._id, req.params.id);
    res.redirect(`/bookings/${booking._id}?status=${booking.status}`);
  } catch (err) {
    res.status(400).render("error", {
      title: "Booking failed",
      message: err.message,
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  }
};

export const postBookSession = async (req, res, next) => {
  try {
    const booking = await bookSessionForUser(req.session.user._id, req.params.id);
    res.redirect(`/bookings/${booking._id}?status=${booking.status}`);
  } catch (err) {
    const message =
      err.code === "DROPIN_NOT_ALLOWED"
        ? "Drop-ins are not allowed for this course."
        : err.message;

    res.status(400).render("error", {
      title: "Booking failed",
      message,
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  }
};

export const bookingConfirmationPage = async (req, res, next) => {
  try {
    const booking = await BookingModel.findById(req.params.bookingId);
    if (!booking)
      return res.status(404).render("error", {
        title: "Not found",
        message: "Booking not found",
        userLoggedIn: !!req.session.user,
        userName: req.session.user?.name || null,
      });

    res.render("booking_confirmation", {
      title: "Booking confirmation",
      booking: {
        id: booking._id,
        type: booking.type,
        status: req.query.status || booking.status,
        createdAt: booking.createdAt ? fmtDate(booking.createdAt) : "",
      },
      userLoggedIn: !!req.session.user,
      userName: req.session.user?.name || null,
    });
  } catch (err) {
    next(err);
  }
};