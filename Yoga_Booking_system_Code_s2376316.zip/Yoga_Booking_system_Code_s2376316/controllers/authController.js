import { UserModel } from "../models/userModel.js"; 
import bcrypt from "bcryptjs";

// Show login page
export const loginPage = (req, res) => {
  res.render("login", { 
    error: null, 
    userLoggedIn: !!req.user,
    emailValue: "" // blank by default
  });
};

// Handle login form
export const postLogin = async (req, res, next) => {
  const { email, password } = req.body;

  try {
    // 🔹 Debug: show what the user submitted
    console.log("Login attempt:", { email, password });

    // Find user by email
    const user = await UserModel.findByEmail(email);

    // 🔹 Debug: what we found in DB
    console.log("User from DB:", user);

    if (!user || !user.passwordHash) {
      console.log("Invalid login: user not found or password missing");
      return res.render("login", { 
        error: "Invalid email or password.", 
        userLoggedIn: false,
        emailValue: email
      });
    }

    // Compare password
    const passwordMatch = await bcrypt.compare(password, user.passwordHash);

    // 🔹 Debug: check if password matches
    console.log("Password match:", passwordMatch);

    if (!passwordMatch) {
      console.log("Invalid login: password does not match");
      return res.render("login", { 
        error: "Invalid email or password.", 
        userLoggedIn: false,
        emailValue: email
      });
    }

    // Save user in session
    req.session.user = { 
      id: user._id, 
      name: user.name, 
      email: user.email, 
      role: user.role 
    };

    console.log("Login successful:", user.email);

    res.redirect("/"); // redirect to homepage
  } catch (err) {
    console.error("Login error:", err);
    next(err);
  }
};

// Logout
export const logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect("/"); // homepage after logout
  });
};