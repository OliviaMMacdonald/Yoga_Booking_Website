// controllers/adminController.js
import { CourseModel } from "../models/courseModel.js";
import { SessionModel } from "../models/sessionModel.js";
import { BookingModel } from "../models/bookingModel.js";
import { UserModel } from "../models/userModel.js";
import bcrypt from "bcryptjs"; // ✅ for hashing passwords

// ----------------------------
// DASHBOARD
// ----------------------------
export const adminDashboard = (req, res) => {
  res.render("admin-dashboard", { userLoggedIn: true, isAdmin: true });
};

// ----------------------------
// COURSES
// ----------------------------
export const listCourses = async (req, res) => {
  const courses = await CourseModel.list();
  res.render("admin-courses", { courses, userLoggedIn: true, isAdmin: true });
};

export const addCoursePage = (req, res) => {
  res.render("admin-add-course", { userLoggedIn: true, isAdmin: true });
};

export const addCourse = async (req, res) => {
  await CourseModel.create(req.body);
  res.redirect("/admin/courses");
};

export const editCoursePage = async (req, res) => {
  const course = await CourseModel.findById(req.params.id);
  res.render("admin-edit-course", { course, userLoggedIn: true, isAdmin: true });
};

export const updateCourse = async (req, res) => {
  await CourseModel.update(req.params.id, req.body);
  res.redirect("/admin/courses");
};

export const deleteCourse = async (req, res) => {
  await CourseModel.delete(req.params.id);
  res.redirect("/admin/courses");
};

// ----------------------------
// SESSIONS
// ----------------------------
export const listSessions = async (req, res) => {
  const course = await CourseModel.findById(req.params.courseId);
  let sessions = await SessionModel.listByCourse(req.params.courseId);

  // Update bookedCount for each session automatically
  sessions = await Promise.all(
    sessions.map(async s => {
      const bookings = await BookingModel.listBySession(s._id);
      return { ...s, bookedCount: bookings.length };
    })
  );

  res.render("admin-sessions", { course, sessions, userLoggedIn: true, isAdmin: true });
};

export const addSessionPage = async (req, res) => {
  const course = await CourseModel.findById(req.params.courseId);
  res.render("admin-add-session", { course, userLoggedIn: true, isAdmin: true });
};

export const addSession = async (req, res) => {
  const sessionData = { ...req.body, courseId: req.params.courseId, bookedCount: 0 };
  await SessionModel.create(sessionData);
  res.redirect(`/admin/courses/${req.params.courseId}/sessions`);
};

export const editSessionPage = async (req, res) => {
  const session = await SessionModel.findById(req.params.id);
  const course = await CourseModel.findById(session.courseId);
  res.render("admin-edit-session", { session, course, userLoggedIn: true, isAdmin: true });
};

export const updateSession = async (req, res) => {
  const session = await SessionModel.update(req.params.id, req.body);
  res.redirect(`/admin/courses/${session.courseId}/sessions`);
};

export const deleteSession = async (req, res) => {
  const session = await SessionModel.findById(req.params.id);
  await SessionModel.delete(req.params.id);
  res.redirect(`/admin/courses/${session.courseId}/sessions`);
};

// ----------------------------
// PARTICIPANTS
// ----------------------------
export const viewParticipants = async (req, res) => {
  const session = await SessionModel.findById(req.params.id);
  const course = await CourseModel.findById(session.courseId);

  const bookings = await BookingModel.listBySession(req.params.id);
  const participants = bookings.map(b => ({
    name: b.user.name,
    email: b.user.email
  }));

  res.render("admin-session-participants", { session, course, participants, userLoggedIn: true, isAdmin: true });
};

// ----------------------------
// USERS
// ----------------------------
export const listUsers = async (req, res) => {
  const users = await UserModel.list();
  res.render("admin-users", { users, userLoggedIn: true, isAdmin: true });
};

export const addUserPage = (req, res) => {
  res.render("admin-add-user", { userLoggedIn: true, isAdmin: true });
};

export const addUser = async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.render("admin-add-user", {
      error: "All fields are required",
      userLoggedIn: true,
      isAdmin: true,
    });
  }

  const passwordHash = await bcrypt.hash(password, 10);

  await UserModel.create({ name, email, passwordHash, role });
  res.redirect("/admin/users");
};

export const deleteUser = async (req, res) => {
  await UserModel.delete(req.params.id);
  res.redirect("/admin/users");
};