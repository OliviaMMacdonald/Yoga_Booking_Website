# Yoga Booking Web Application

## Overview
A Node.js and Express application for managing yoga class bookings, sessions, and users. Includes secure authentication, session management, and admin-controlled user management.

## Features
- User registration and login with password hashing (bcrypt)
- Session-based authentication with `express-session`
- Admin-protected routes for user management:
  - View all users
  - Update user details
  - Delete users
- Course, session, and booking management via `/api` routes
- Server-side rendering with Mustache templates, including partials
- Static file serving from `/public`
- Health check endpoint at `/health`

## Technologies Used
- Node.js
- Express.js
- NeDB (nedb-promises)
- Mustache (mustache-express)
- bcryptjs
- express-session & cookie-parser
- dotenv
- jsonwebtoken (if used for API auth)

## Installation Instructions
1. Download or extract the project files
2. Open the project folder in a terminal
3. Install dependencies:
```bash
npm install


Running the Application 

1. Start the server - npm start 
2. Development mode (auto-restart) - npm run dev 
3. Seed the database (optional) - npm run seed 
4. Running Tests - npm test 

Accessing the Application 
open your browser - http://localhost:3000

Example Routes / How to Use

Public Routes (accessible without login)
	•	GET / → Home page
	•	GET /health → Health check endpoint (returns JSON { ok: true })
	•	GET /api/courses → View all courses
	•	GET /api/sessions → View all class sessions
	•	GET /api/bookings → View bookings

User Routes (requires login)
	•	POST /api/bookings → Create a new booking
	•	GET /profile → View user profile (if implemented)

Admin Routes (requires admin login)
	•	GET /admin → Admin dashboard
	•	GET /admin/users → View all registered users
	•	POST /admin/users/delete/:id → Delete a user by ID
	•	POST /admin/users/update/:id → Update a user’s details

Project Structure
	•	controllers/ → Application logic
	•	models/ → Database interaction (UserModel, etc.)
	•	routes/ → API and view routes
	•	views/ → Mustache templates (with partials)
	•	public/ → Static assets (CSS, JS, images)
	•	seed/ → Database seeding scripts
	•	index.js → Main server file

Enviornment Variables 
    create a .env file if needed:
    PORT=3000
    SESSION_SECRET=your_secret_here
    JWT_SECRET=your_secret_here

Notes 
- node_modules is not included in the submission 
- All dependencies listed in package .json
- Ensure Node.js is installed before running 

Author 
Olivia Macdonald 