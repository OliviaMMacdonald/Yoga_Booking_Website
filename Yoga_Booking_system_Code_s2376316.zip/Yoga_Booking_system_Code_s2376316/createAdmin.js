import { UserModel } from "./models/userModel.js";
import bcrypt from "bcryptjs";
import { initDb } from "./models/_db.js";

async function createAdmin() {
  try {
    await initDb();

    // Use the custom findByEmail method
    const existingAdmin = await UserModel.findByEmail("admin@example.com");
    if (existingAdmin) {
      console.log("Admin user already exists!");
      process.exit(0);
    }

    const passwordHash = await bcrypt.hash("password123", 10);

    await UserModel.create({
      name: "Admin",
      email: "admin@example.com",
      passwordHash,
      role: "admin",
    });

    console.log("Admin user created safely!");
    process.exit(0);
  } catch (err) {
    console.error("Error creating admin user:", err);
    process.exit(1);
  }
}

createAdmin();