import { usersDb } from "./models/_db.js";
import bcrypt from "bcryptjs";

async function resetAdmin() {
  const newPassword = "SuperSecureAdmin123";
  const hash = await bcrypt.hash(newPassword, 10);

  const result = await usersDb.update(
    { email: "admin@example.com" },
    { $set: { passwordHash: hash } }
  );

  console.log("Admin password reset:", result);
  process.exit(0);
}

resetAdmin();