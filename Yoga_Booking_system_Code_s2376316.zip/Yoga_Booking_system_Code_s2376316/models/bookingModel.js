// models/bookingModel.js
import { bookingsDb } from "./_db.js"; // make sure you have a bookingsDb in _db.js

export const BookingModel = {
  // Create a booking
  async create(booking) {
    // booking = { sessionId, user: { id, name, email }, paid: true/false }
    return bookingsDb.insert(booking);
  },

  // List all bookings for a specific session
  async listBySession(sessionId) {
    return bookingsDb.find({ sessionId });
  },

  // Find a booking by its ID
  async findById(id) {
    return bookingsDb.findOne({ _id: id });
  },

  // Delete a booking by its ID
  async delete(id) {
    return bookingsDb.remove({ _id: id });
  },
};
