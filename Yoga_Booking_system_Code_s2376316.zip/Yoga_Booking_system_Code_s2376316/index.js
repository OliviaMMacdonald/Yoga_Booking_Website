import express from "express";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import mustacheExpress from "mustache-express";
import path from "path";
import { fileURLToPath } from "url";
import session from "express-session";

import courseRoutes from "./routes/courses.js";       
import sessionRoutes from "./routes/sessions.js";     
import bookingRoutes from "./routes/bookings.js";     
import viewRoutes from "./routes/views.js";  
import adminRoutes from "./routes/adminRoutes.js";      

import { initDb } from "./models/_db.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// ----------------------------
// VIEW ENGINE
// ----------------------------
app.engine(
  "mustache",
  mustacheExpress(path.join(__dirname, "views", "partials"), ".mustache")
);
app.set("view engine", "mustache");
app.set("views", path.join(__dirname, "views"));

// ----------------------------
// MIDDLEWARE
// ----------------------------
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser());

// Static files
app.use("/static", express.static(path.join(__dirname, "public")));

// ----------------------------
// SESSION
// ----------------------------
app.use(
  session({
    secret: "supersecretkey",
    resave: false,
    saveUninitialized: false,
  })
);

// ----------------------------
// GLOBAL USER DATA (FIXED)
// ----------------------------
app.use((req, res, next) => {
  res.locals.userLoggedIn = !!req.session.user;
  res.locals.userName = req.session.user?.name || null;
  res.locals.userRole = req.session.user?.role || null;

  // ✅ THIS IS THE IMPORTANT FIX
  res.locals.isAdmin = req.session.user?.role === "admin";

  next();
});

// ----------------------------
// ROUTES
// ----------------------------
app.get("/health", (req, res) => res.json({ ok: true }));

app.use("/api/courses", courseRoutes);
app.use("/api/sessions", sessionRoutes);
app.use("/api/bookings", bookingRoutes);

app.use("/admin", adminRoutes);
app.use("/", viewRoutes);

// ----------------------------
// ERROR HANDLING
// ----------------------------
const not_found = (req, res) =>
  res.status(404).type("text/plain").send("404 Not found.");

const server_error = (err, req, res, next) => {
  console.error(err);
  res.status(500).type("text/plain").send("Internal Server Error.");
};

app.use(not_found);
app.use(server_error);

// ----------------------------
// START SERVER
// ----------------------------
if (process.env.NODE_ENV !== "test") {
  await initDb();
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () =>
    console.log(`Yoga booking running on http://localhost:${PORT}`)
  );
}