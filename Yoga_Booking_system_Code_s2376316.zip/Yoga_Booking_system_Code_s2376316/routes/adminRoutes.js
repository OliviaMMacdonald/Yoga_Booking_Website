// routes/adminRoutes.js
import express from "express";
import * as adminController from "../controllers/adminController.js";
import { requireAdmin } from "../middlewares/auth.js";

const router = express.Router();

// ----------------------------
// DASHBOARD
// ----------------------------
router.get("/", requireAdmin, adminController.adminDashboard);

// ----------------------------
// COURSES
// ----------------------------
router.get("/courses", requireAdmin, adminController.listCourses);
router.get("/courses/add", requireAdmin, adminController.addCoursePage);
router.post("/courses/add", requireAdmin, adminController.addCourse);
router.get("/courses/:id/edit", requireAdmin, adminController.editCoursePage);
router.post("/courses/:id/edit", requireAdmin, adminController.updateCourse);
router.post("/courses/:id/delete", requireAdmin, adminController.deleteCourse);

// ----------------------------
// SESSIONS
// ----------------------------
router.get("/courses/:courseId/sessions", requireAdmin, adminController.listSessions);
router.get("/courses/:courseId/sessions/add", requireAdmin, adminController.addSessionPage);
router.post("/courses/:courseId/sessions/add", requireAdmin, adminController.addSession);
router.get("/sessions/:id/edit", requireAdmin, adminController.editSessionPage);
router.post("/sessions/:id/edit", requireAdmin, adminController.updateSession);
router.post("/sessions/:id/delete", requireAdmin, adminController.deleteSession);

// ----------------------------
// PARTICIPANTS
// ----------------------------
router.get("/sessions/:id/participants", requireAdmin, adminController.viewParticipants);

// ----------------------------
// USERS
// ----------------------------
router.get("/users", requireAdmin, adminController.listUsers);
router.get("/users/add", requireAdmin, adminController.addUserPage);
router.post("/users/add", requireAdmin, adminController.addUser);
router.post("/users/:id/delete", requireAdmin, adminController.deleteUser);

export default router;