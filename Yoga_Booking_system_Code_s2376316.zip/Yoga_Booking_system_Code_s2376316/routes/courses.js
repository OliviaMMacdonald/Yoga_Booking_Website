// routes/courses.js
import { Router } from "express";
import { CourseModel } from "../models/courseModel.js";
import { SessionModel } from "../models/sessionModel.js";

const router = Router();

// === SSR: Render courses page for public users ===
router.get("/view", async (req, res) => {
  const coursesRaw = await CourseModel.list(); // get all courses

  // Grab filters from query parameters
  const filters = {
    level: req.query.level || "",
    q: req.query.q || ""
  };

  // Filter courses by level if selected
  let courses = coursesRaw;
  if (filters.level) {
    courses = courses.filter(c => c.level.toLowerCase() === filters.level.toLowerCase());
  }

  // Filter courses by search query if provided
  if (filters.q) {
    const qLower = filters.q.toLowerCase();
    courses = courses.filter(c =>
      c.title.toLowerCase().includes(qLower) || c.description.toLowerCase().includes(qLower)
    );
  }

  // Attach sessions to each course
  for (let course of courses) {
    const sessionsRaw = await SessionModel.listByCourse(course._id);
    course.sessions = sessionsRaw.map(s => ({
      date: new Date(s.startDateTime).toLocaleDateString(),
      time: new Date(s.startDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      location: s.location || "Studio"
    }));

    // Optional: show next session and total sessions
    course.nextSession = sessionsRaw.length
      ? new Date(sessionsRaw[0].startDateTime).toLocaleString()
      : "TBA";
    course.sessionsCount = sessionsRaw.length;
  }

  // Helpers for Mustache template
  const helpers = {
    isBeginner: (level) => level === "beginner",
    isIntermediate: (level) => level === "intermediate",
    isAdvanced: (level) => level === "advanced",
    isEmpty: (value) => !value
  };

  res.render("courses.mustache", { courses, filters, ...helpers });
});

// === JSON API routes ===

// List courses as JSON
router.get("/", async (req, res) => {
  const courses = await CourseModel.list();
  res.json({ courses });
});

// Create a new course (admin/API use)
router.post("/", async (req, res) => {
  const course = await CourseModel.create(req.body);
  res.status(201).json({ course });
});

// Get course + sessions (JSON)
router.get("/:id", async (req, res) => {
  const course = await CourseModel.findById(req.params.id);
  if (!course) return res.status(404).json({ error: "Course not found" });
  const sessions = await SessionModel.listByCourse(course._id);
  res.json({ course, sessions });
});

export default router;