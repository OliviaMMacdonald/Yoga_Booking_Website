import { Router } from "express";
import { homePage, courseDetailPage, postBookCourse, postBookSession, bookingConfirmationPage } from "../controllers/viewsController.js";
import { coursesListPage } from "../controllers/coursesListController.js";
import { loginPage, postLogin, logout } from "../controllers/authController.js"; // ✅ import your real login/logout

const router = Router();

// ----------------------------
// LOGIN / LOGOUT ROUTES
// ----------------------------
router.get("/login", loginPage);
router.post("/login", postLogin);   // ✅ real login check
router.get("/logout", logout);

// ----------------------------
// MAIN PAGES
// ----------------------------
router.get("/", homePage);
router.get("/courses", coursesListPage);
router.get("/courses/:id", courseDetailPage);
router.post("/courses/:id/book", postBookCourse);
router.post("/sessions/:id/book", postBookSession);
router.get("/bookings/:bookingId", bookingConfirmationPage);

export default router;