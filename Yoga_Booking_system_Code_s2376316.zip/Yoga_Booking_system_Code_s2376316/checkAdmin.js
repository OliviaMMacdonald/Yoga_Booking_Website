// checkAdmin.js
import { UserModel } from "./models/userModel.js";
import { initDb } from "./models/_db.js";

async function checkAdmin() {
  try {
    await initDb();

    // Replace with the actual admin email you expect
    const adminEmail = "admin@example.com"; 
    const admin = await UserModel.findByEmail(adminEmail);

    if (admin && admin.role === "admin") {
      console.log("Admin user exists!");
      console.log("Name:", admin.name);
      console.log("Email:", admin.email);
    } else {
      console.log("No admin user found.");
    }
  } catch (err) {
    console.error("Error checking admin user:", err);
  } finally {
    process.exit(0);
  }
}

checkAdmin();