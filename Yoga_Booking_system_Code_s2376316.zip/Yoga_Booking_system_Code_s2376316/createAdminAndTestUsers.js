// createAdminAndTestUsers.js
import bcrypt from "bcryptjs";
import { UserModel } from "./models/userModel.js";

async function setupUsers() {
  try {
    // ----------------------------
    // Admin
    // ----------------------------
    const adminEmail = "admin@example.com";
    let admin = await UserModel.findByEmail(adminEmail);

    if (!admin) {
      const adminPasswordHash = await bcrypt.hash("SuperSecureAdmin123", 10);
      await UserModel.create({
        name: "Admin",
        email: adminEmail,
        passwordHash: adminPasswordHash,
        role: "admin",
      });
      console.log("Admin user created!");
    } else {
      console.log("Admin already exists.");
    }

    // ----------------------------
    // Fiona
    // ----------------------------
    const fionaEmail = "fiona@example.com";
    let fiona = await UserModel.findByEmail(fionaEmail);

    if (!fiona) {
      const fionaPasswordHash = await bcrypt.hash("password123", 10);
      await UserModel.create({
        name: "Fiona",
        email: fionaEmail,
        passwordHash: fionaPasswordHash,
        role: "user",
      });
      console.log("Fiona user created!");
    } else if (!fiona.passwordHash) {
      const fionaPasswordHash = await bcrypt.hash("password123", 10);
      await UserModel.update(fiona._id, { passwordHash: fionaPasswordHash });
      console.log("Fiona's password fixed!");
    } else {
      console.log("Fiona already exists with valid password.");
    }

    console.log("✅ Users setup complete!");
    process.exit(0);
  } catch (err) {
    console.error("Error setting up users:", err);
    process.exit(1);
  }
}

setupUsers();